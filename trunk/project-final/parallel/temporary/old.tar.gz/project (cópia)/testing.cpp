#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "trie.h"
#include "random.h"

Trie t;
int id = 0, left = 0;
Info words[NUM_WORDS];

pthread_t threads[NUM_THREADS];
pthread_mutex_t mutexes[26]; // 26 letters
pthread_mutex_t found;

void* function(void* ptr)
{
	Random r;
	r.seed();
	int last = 0;
	while (left)
	{
		last = left;
		t.process(words, r.next(), id, left, mutexes, found);
		//if (last != left) printf("%d\n", left);
	}
	return NULL;
}

int main()
{
	srand(time(NULL));
	
	while (scanf("%s", words[id].str) == 1)
	{
		int len = strlen(words[id].str);
		int num = len/MAX_WORD_LEN;
		if (len%MAX_WORD_LEN) ++num;
		words[id].len = num;
		t.insert(words[id].str, &t, id);
		++id;
		left += num;
	}
	
	for (int i = 0; i < 26; ++i)
		pthread_mutex_init(&mutexes[i], NULL);
	pthread_mutex_init(&found, NULL);
	
	for (int i = 0; i < NUM_THREADS; ++i)
	{
		pthread_create(&threads[i], NULL, function, NULL);
	}
	
	for (int i = 0; i < NUM_THREADS; ++i)
		pthread_join(threads[i], NULL);
	
	t.clean();
	
	return 0;
}

