#include "info.h"

/**
 * Constructor.
 */
InfoSet::InfoSet(int id, int mask)
{
	this->id = id;
	this->mask = mask;
}
